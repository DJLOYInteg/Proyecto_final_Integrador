package com.hotel.server.Emuns;

public enum TypeDocE {
  DNI,
  PASAPORTE,
  CARNET_EXTRANJERIA,
}
