package com.hotel.server.Emuns;

public enum CategoryRoomE {
  PLATA, ORO, DIAMANTE
}
