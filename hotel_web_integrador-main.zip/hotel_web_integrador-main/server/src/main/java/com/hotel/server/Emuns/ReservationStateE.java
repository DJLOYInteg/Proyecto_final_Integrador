package com.hotel.server.Emuns;

public enum ReservationStateE {
  PENDIENTE, CANCELADO, FINALIZADO
}
