package com.hotel.server.Emuns;

public enum RoomStateE {
  DISPONIBLE, OCUPADO, MANTENIMIENTO
}
