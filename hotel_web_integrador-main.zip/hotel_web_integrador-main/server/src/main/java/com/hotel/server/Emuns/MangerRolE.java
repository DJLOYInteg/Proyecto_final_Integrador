package com.hotel.server.Emuns;

public enum MangerRolE {
  ADMIN, RECEPCIONISTA
}
