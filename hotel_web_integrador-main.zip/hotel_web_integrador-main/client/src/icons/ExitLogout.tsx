import { IoExitOutline } from 'react-icons/io5'
import { IconProps } from './icon'
export const ExitLogout = ({ className }: IconProps) => (
	<IoExitOutline className={className} />
)
